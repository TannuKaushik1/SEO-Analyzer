
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

@app.route('/analyze', methods=['POST'])
def analyze():
    content = request.json.get('text', '')
    analysis = {
        "readability_score": 65.5,
        "word_count": len(content.split()),
        "character_count": len(content),
    }
    words = list(set(content.lower().split()))
    keywords = [w for w in words if len(w) > 4][:5]
    return jsonify({"analysis": analysis, "keywords": keywords})

if __name__ == '__main__':
    app.run(debug=True)
