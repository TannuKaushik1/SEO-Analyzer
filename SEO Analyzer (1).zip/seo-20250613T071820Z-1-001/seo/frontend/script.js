
function analyzeText() {
  const text = document.getElementById('textInput').value;
  const resultsDiv = document.getElementById('seoResults');
  const keywordsDiv = document.getElementById('keywords');

  if (!text.trim()) {
    resultsDiv.textContent = 'Please enter some content to analyze.';
    return;
  }

  const characterCount = text.length;
  const wordCount = text.trim().split(/\s+/).length;
  const readabilityScore = (206.835 - 1.015 * wordCount - 84.6 * (text.split('.').length)).toFixed(1);

  const keywords = [...new Set(text.toLowerCase().match(/\b\w{6,}\b/g))].slice(0, 5);

  resultsDiv.textContent = JSON.stringify({
    character_count: characterCount,
    word_count: wordCount,
    readability_score: readabilityScore
  }, null, 2);

  keywordsDiv.innerHTML = keywords.map(word => `<button onclick="insertKeyword('${word}')">${word}</button>`).join('');
}

function insertKeyword(word) {
  const input = document.getElementById('textInput');
  input.value += (input.value.endsWith(' ') ? '' : ' ') + word;
}

function toggleDarkMode() {
  document.body.classList.toggle('dark-mode');
}
